import vrep
import sys
from random import random
import numpy as np


class Robot():
	def __init__(self, clientID,speed):
		self.clientID = clientID
		self.leftDir = 0
		self.rightDir = 0
		self.linearVelocityLeft = 0
		self.linearVelocityRight = 0
		self.linearMax = speed
		self.colorSensorOutput = [0,0,0]
		self.lineSensorOutput = [0,0,0]
		self.colorSensorPulseCount = 0


		#motor  Module
		errorCode,self.LeftMotor=vrep.simxGetObjectHandle(self.clientID,'LeftJoint',vrep.simx_opmode_oneshot_wait)
		errorCode,self.RightMotor=vrep.simxGetObjectHandle(self.clientID,'RightJoint',vrep.simx_opmode_oneshot_wait)

		#Sensor Module
		errorCode, self.LineSensor = vrep.simxGetObjectHandle(self.clientID, 'LineSensor', vrep.simx_opmode_oneshot_wait);
		errorCode, self.ColorSensor = vrep.simxGetObjectHandle(self.clientID, 'ColorSensor', vrep.simx_opmode_oneshot_wait);

		#Robot itself
		errorCode, self.eBot = vrep.simxGetObjectHandle(self.clientID, 'eBot', vrep.simx_opmode_oneshot_wait);

		#Obstacle
		errorCode, self.Obs1 = vrep.simxGetObjectHandle(self.clientID, 'Obs1', vrep.simx_opmode_oneshot_wait);
		errorCode, self.Obs2 = vrep.simxGetObjectHandle(self.clientID, 'Obs2', vrep.simx_opmode_oneshot_wait);
		errorCode, self.Obs3 = vrep.simxGetObjectHandle(self.clientID, 'Obs3', vrep.simx_opmode_oneshot_wait);

		#PRoximity Sensor
		errorCode, self.ProximitySensor = vrep.simxGetObjectHandle(self.clientID, 'ProximitySensor', vrep.simx_opmode_oneshot_wait);
		print("Robot Initilized")

	def forward(self):
		self.leftDir = self.rightDir = 1
		self.linearVelocityLeft= self.linearVelocityRight = self.linearMax

	def back(self):
		self.leftDir = self.rightDir = -1
		self.linearVelocityLeft= self.linearVelocityRight = self.linearMax

	def softRight(self):
		self.leftDir = 1
		self.rightDir = 0
		self.linearVelocityLeft=  self.linearMax
		self.linearVelocityRight = 0

	def right(self):
		self.leftDir = 1
		self.rightDir = -1
		self.linearVelocityLeft=  self.linearMax
		self.linearVelocityRight =  -self.linearMax

	def softLeft(self):
		self.leftDir = 0
		self.rightDir = 1
		self.linearVelocityLeft=  0
		self.linearVelocityRight = self.linearMax

	def left(self):
		self.leftDir = -1
		self.rightDir = 1
		self.linearVelocityLeft=  -self.linearMax
		self.linearVelocityRight =  self.linearMax

	def softLeft(self):
		self.leftDir = 0
		self.rightDir = 0
		self.linearVelocityLeft=  0
		self.linearVelocityRight = 0

	def velocity(self,left , right):
		if left > 255:
			left = 255
		elif left < 0:
			left = 0
		if right > 255:
			right = 255
		elif right < 0:
			right = 0;
		self.linearVelocityLeft = self.leftDir * self.linearMax*left / 255.0
		self.linearVelocityRight = self.rightDir * self.linearMax*right / 255.0
	
	def getLineSensorData(self):
		err,resolution,lineSensorOutput =  vrep.simxGetVisionSensorImage(self.clientID,self.LineSensor,1,vrep.simx_opmode_buffer)

		if lineSensorOutput:
			self.lineSensorOutput = np.array(lineSensorOutput ,dtype=np.uint8)
			return self.lineSensorOutput
		else:
			return [0,0,0]

	def getColorSensorData(self):
		err,resolution,colorSensorOutput =  vrep.simxGetVisionSensorImage(self.clientID, self.ColorSensor, 0, vrep.simx_opmode_buffer)
		if colorSensorOutput:
			self.colorSensorOutput = np.array(colorSensorOutput ,dtype=np.uint8)
			return self.colorSensorOutput
		else:
			return [0,0,0]
	def initVisionSensors(self):
		while True :
			err, resolution, image = vrep.simxGetVisionSensorImage(self.clientID, self.LineSensor, 1, vrep.simx_opmode_streaming)
			if err != vrep.simx_return_ok  or  err == vrep.simx_return_novalue_flag:
				break

		while True :
			err, resolution, image = vrep.simxGetVisionSensorImage(self.clientID, self.ColorSensor, 0, vrep.simx_opmode_streaming)
			if err != vrep.simx_return_ok  or  err == vrep.simx_return_novalue_flag:
				break

		for x in xrange(1,2000):
			self.getLineSensorData()
			self.getColorSensorData()

	def getProxSensorDistance(self):
		errorCode,detectionState,detectedPoint, detectedObjectHandle, detectedSurfaceNormalVector = vrep.simxReadProximitySensor(self.clientID, self.ProximitySensor, vrep.simx_opmode_buffer)
		retval = 140
		if detectionState:
			retval = detectedPoint[2] * 1000
		else:
			retval -= random() % 40
		return retval

	def filter_red(self):
		self.getColorSensorData()
		self.colorSensorPulseCount = int(self.colorSensorOutput[0] * 5000 / 255.0)+(random()%1001)


	def filter_green(self):
		self.getColorSensorData()
		self.colorSensorPulseCount = int(self.colorSensorOutput[1] * 5000 / 255.0)+(random()%1001)

	def filter_blue(self):
		self.getColorSensorData()
		self.colorSensorPulseCount = int(self.colorSensorOutput[2] * 5000 / 255.0)+(random()%1001)

	def filter_clear(self):
		self.getColorSensorData()
		self.colorSensorPulseCount = int((self.colorSensorOutput[0]+ self.colorSensorOutput[1]+ self.colorSensorOutput[2]) * 5000 / 255.0)+(random()%1001)

	def initProxSensor(self):
		while True:
			errorCode, detectionState, detectedPoint, detectedObjectHandle, detectedSurfaceNormalVector = vrep.simxReadProximitySensor(self.clientID, self.ProximitySensor, vrep.simx_opmode_streaming)
			if errorCode != vrep.simx_return_ok or errorCode == vrep.simx_error_novalue_flag:
				break
	def initSensors(self):
		self.initProxSensor()
		self.initVisionSensors()


	def ADC_Conversion(self,ch_no):
		if ch_no == 1:
			return self.lineSensorOutput[0]
		elif ch_no == 2:
			return self.lineSensorOutput[1]
		elif ch_no == 3:
			return self.lineSensorOutput[2]
		elif ch_no == 4:
			return self.getProxSensorDistance();
		return 255;

	def setJointVelocities(self,left,right):
		errorCode=vrep.simxSetJointTargetVelocity(self.clientID,self.LeftMotor,left, vrep.simx_opmode_streaming)
		errorCode=vrep.simxSetJointTargetVelocity(self.clientID,self.RightMotor,right, vrep.simx_opmode_streaming)
		return errorCode

	def disconnect(self):
		self.clientID = -1
		print("Robot Disconnected")
	
	def threadoperation(self):
		print("Wheel Velocity Thread Started")
		while self.clientID != -1 :
			self.setJointVelocities(self.linearVelocityLeft,self.linearVelocityRight)
			self.getLineSensorData()
		return 1