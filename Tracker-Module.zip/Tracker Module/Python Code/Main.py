import threading
import time
import vrep
import sys
from Simulator import Simulator
from Robot import Robot
import cv2
import numpy as np

simulator = Simulator('127.0.0.1',19999)
simulationID = simulator.connect()
robot = Robot(simulationID,10)

try:
	tmp = threading.Thread(target=robot.threadoperation)
	tmp.start()
except:
	print("Error in Strating Thread")

robot.initSensors()
while True:

	# #Your Code goes here
	robot.disconnect()
	simulator.stop()
	sys.exit()





