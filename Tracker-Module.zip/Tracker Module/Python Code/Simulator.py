import vrep
import sys

class Simulator():
	def __init__(self,host,port):
		self.host = host
		self.port = port

	def connect(self):
		vrep.simxFinish(-1) # just in case, close all opened connections
		clientID = vrep.simxStart(self.host,self.port,True,True,5000,5) # Get the client ID
		if clientID!=-1:  #check if client connection successful
			self.clientID = clientID
			print('Vrep Connected')
			return self.clientID
		else:
			print('Connection not successful')
			sys.exit('Could not connect')
	def stop(self):
		while True:
			check = vrep.simxStopSimulation(self.clientID, vrep.simx_opmode_oneshot_wait);
			if check != vrep.simx_return_ok :
				break
		vrep.simxFinish(-1)
		print("Simulation Stop")